public class BST {
    private class BSTNode {
        Course course;
        BSTNode left, right;
        BSTNode(Course course) { this.course = course; }
    }

    private BSTNode root;

    public void insert(Course course) { root = insert(root, course); }
    private BSTNode insert(BSTNode node, Course course) {
        if (node == null) return new BSTNode(course);
        int cmp = course.courseId.compareTo(node.course.courseId);
        if (cmp < 0) node.left = insert(node.left, course);
        else if (cmp > 0) node.right = insert(node.right, course);
        else System.out.println("Course ID exists!");
        return node;
    }

    public Course search(String courseId) { return search(root, courseId); }
    private Course search(BSTNode node, String courseId) {
        if (node == null) return null;
        int cmp = courseId.compareTo(node.course.courseId);
        if (cmp < 0) return search(node.left, courseId);
        else if (cmp > 0) return search(node.right, courseId);
        else return node.course;
    }

    public void delete(String courseId) { root = delete(root, courseId); }
    private BSTNode delete(BSTNode node, String courseId) {
        if (node == null) return null;
        int cmp = courseId.compareTo(node.course.courseId);
        if (cmp < 0) node.left = delete(node.left, courseId);
        else if (cmp > 0) node.right = delete(node.right, courseId);
        else {
            if (node.right == null) return node.left;
            if (node.left == null) return node.right;
            BSTNode temp = node;
            node = min(temp.right);
            node.right = deleteMin(temp.right);
            node.left = temp.left;
        }
        return node;
    }

    private BSTNode min(BSTNode node) {
        return node.left == null ? node : min(node.left);
    }

    private BSTNode deleteMin(BSTNode node) {
        if (node.left == null) return node.right;
        node.left = deleteMin(node.left);
        return node;
    }

    public void display() { display(root); }
    private void display(BSTNode node) {
        if (node == null) return;
        display(node.left);
        System.out.println("- " + node.course.courseId + ": " + node.course.courseName + 
                         " (" + node.course.availableSeats() + "/" + node.course.maxSeats + ")");
        display(node.right);
    }
}
