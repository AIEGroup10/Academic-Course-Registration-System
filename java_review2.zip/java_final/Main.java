public class Main {
    public static void main(String[] args) {
        // Creating Course instances
        Course c1 = new Course("0100", "Introduction to programming", 10);
        Course c2 = new Course("0101", "Mathematics for computing", 10);
        Course c3 = new Course("0102", "Mechanical Physics", 10);

        // Creating Student instances
        Student s1 = new Student("Henry", "1234", "1234554321", "H@rini8899");
        Student s2 = new Student("John", "2345", "1234567890", "g@rini99");

        // Registering students to courses
        s1.registerCourse(c1);
        s2.registerCourse(c2);

        // Creating Admin instance with shared BST reference
        Admin a1 = new Admin("Shiva", "1235", "4566789076", "k@paul88");

        // Admin adding courses to the catalog
        a1.addCourse(c3);
        a1.addCourse(c2);
        a1.addCourse(c1);        
    }
}
